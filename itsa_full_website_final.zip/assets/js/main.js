// main.js — core helpers, nav control, toast, modal, auth helpers, search/event join
(function(){
  function showToast(msg, timeout=2500){
    let t = document.getElementById('__itsa_toast');
    if(!t){
      t = document.createElement('div'); t.id='__itsa_toast'; t.className='toast'; document.body.appendChild(t);
    }
    t.textContent = msg; t.classList.add('show');
    clearTimeout(t._h); t._h = setTimeout(()=> t.classList.remove('show'), timeout);
  }

  function showModal(html){
    let backdrop = document.createElement('div'); backdrop.className='modal-backdrop';
    let modal = document.createElement('div'); modal.className='modal';
    modal.innerHTML = html;
    backdrop.appendChild(modal);
    backdrop.onclick = (e)=> { if(e.target === backdrop) backdrop.remove(); };
    document.body.appendChild(backdrop);
    return {backdrop,modal};
  }

  function updateNavigation(){
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    document.querySelectorAll('.protected').forEach(e=>{
      if(isLoggedIn){ e.classList.remove('locked'); e.style.pointerEvents='auto'; e.classList.add('fade-in'); }
      else { e.classList.add('locked'); e.style.pointerEvents='none'; }
    });

    // active page highlight
    const current = window.location.pathname.split('/').pop() || 'Itsa Platform.html';
    document.querySelectorAll('.nav a').forEach(a=>{
      a.classList.remove('active');
      if(a.getAttribute('href') === current) a.classList.add('active');
    });

    const loginBtn = document.getElementById('loginBtn');
    if(loginBtn){
      if(isLoggedIn){
        loginBtn.textContent='Logout';
        loginBtn.href='#';
        loginBtn.onclick = function(){ localStorage.removeItem('isLoggedIn'); showToast('Logged out'); location.href='Itsa Platform.html'; };
      } else {
        loginBtn.textContent='SignUp/SignIn';
        loginBtn.href='login.html';
        loginBtn.onclick = null;
      }
    }

    // locked tabs click behaviour (show modal)
    document.querySelectorAll('.nav a.locked').forEach(tab=>{
      tab.onclick = function(e){ e.preventDefault(); showModal('<div style="padding:12px"><h3>Please login</h3><p>To access this section please login first.</p><div style="text-align:right;margin-top:12px"><button class="btn" onclick="document.querySelector(\'.modal-backdrop\').remove()">Close</button> <button class="btn" onclick="location.href=\'login.html\'">Login</button></div></div>'); };
    });
  }

  // expose for pages
  window.showToast = showToast;
  window.showModal = showModal;
  window.updateNavigation = updateNavigation;

  document.addEventListener('DOMContentLoaded',updateNavigation);

  // small utilities for app
  window.getRegisteredUser = function(){ return JSON.parse(localStorage.getItem('registeredUser')||'null'); };
  window.saveRegisteredUser = function(u){ localStorage.setItem('registeredUser', JSON.stringify(u)); };
  window.joinEvent = function(eventId){
    let joined = JSON.parse(localStorage.getItem('joinedEvents')||'[]');
    if(!joined.includes(eventId)){ joined.push(eventId); localStorage.setItem('joinedEvents', JSON.stringify(joined)); showToast('You joined the event'); }
    else showToast('You already joined');
  };
})();